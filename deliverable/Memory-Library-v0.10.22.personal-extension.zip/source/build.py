from pathlib import Path
import json,zipfile
root=Path(__file__).resolve().parent
out=root.parent/'deliverable'
out.mkdir(exist_ok=True)
manifest={"kind":"marinara.personal-extension","version":1,"config":{"name":"기억 서재","version":"0.10.22","description":"줄거리·관계 / 에피소드 / 장기 기억·발언을 분리하고 생성 전 임베딩·장면 검색으로 필요한 과거를 주입하는 검증 버전. 기본 10개 메시지 묶음 분석·시간 대조, 전체 대화 AI 챕터 자동 분류·이어하기, 활성 요약 가져오기와 시작·끝 메시지 구간 수집, 파일 인덱스형 챕터 UI·AI 제목·다크모드·토글·넓은 요약 편집창, 정확한 인용 문자열 검사, 주입 내역·백업·되돌리기·채팅방 이름과 턴 수·방별 기억 선택을 지원. 기존 요약·LTM 설정은 자동으로 변경하지 않음. 임베딩·단어 혼합 검색, 기본 12,000 추정 토큰 예산, 최종 기억 개수 제한 없음. 에피소드별 다중 사건·육하원칙·결과·다중 발언 편집과 자동 분류 지원.","runtime":"client","enabled":False,"capabilities":["full_page_access"],"jsPath":"extension.js","cssPath":"extension.css"}}
js='/* Memory Library v0.10.22 — based on host integration paths in supplied Anon Community v2.3.42 */\n'+(root/'core.cjs').read_text()+'\n'+(root/'runtime.js').read_text().replace("/*__UI_CSS__*/ ''","/*__UI_CSS__*/ "+json.dumps((root/'ui.css').read_text(),ensure_ascii=False))
(out/'extension.js').write_text(js)
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(out/'extension.css').write_text('/* UI styles live in an isolated ShadowRoot. */\n')
with zipfile.ZipFile(out/'Memory-Library-v0.10.22.personal-extension.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['manifest.json','extension.js','extension.css']:z.write(out/name,name)
 if (root/'RELEASE-NOTES.md').exists():z.write(root/'RELEASE-NOTES.md','RELEASE-NOTES.md')
 z.write((root/'README.md' if (root/'README.md').exists() else root.parent/'README.md'),'README.md')
 for name in ['core.cjs','runtime.js','core.test.cjs','browser.test.cjs','runtime.test.cjs','dom.test.cjs','ui.css','build.py']:z.write(root/name,'source/'+name)
print(out/'Memory-Library-v0.10.22.personal-extension.zip')
